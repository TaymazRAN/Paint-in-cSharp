﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Paint
{
    public partial class ma : Form
    {
        public ma()
        {
            InitializeComponent();
        }
    }
}
