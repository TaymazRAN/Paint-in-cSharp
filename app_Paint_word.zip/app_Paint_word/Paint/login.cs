﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Paint
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (text_namekarbari.Text == "1" && text_ramzeobor.Text == "1")
            {
                //  Form1 m1;
                this.Visible = false;
                Form f = new Main();
                f.Show();
            }
            else { MessageBox.Show("اشتباه وارد شده است ", "خطای ورود به سیستم ", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
